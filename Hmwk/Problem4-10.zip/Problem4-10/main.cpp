/* 
 * File:   main.cpp
 * Author: Seth Tyler
 * Purpose: What will the following program display?
 *
 * Created on February 28, 2018, 8:21 PM
 */

// System libraries
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    // Declare variables
    int sales = 0;
    int bonus = 0;
    float commissionRate = 0;
    
    if (sales > 50,000) {
        commissionRate = 0.25;
        bonus = 250;
    }
    
    // The program will display a 9, 9.5, and a 9.
    
    return 0;
}

