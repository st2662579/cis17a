var files_dup =
[
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "Card.h", "_card_8h.html", [
      [ "Card", "struct_card.html", "struct_card" ]
    ] ],
    [ "Deck.h", "_deck_8h.html", [
      [ "Deck", "struct_deck.html", "struct_deck" ]
    ] ],
    [ "Hand.h", "_hand_8h.html", [
      [ "Deck", "struct_deck.html", "struct_deck" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];