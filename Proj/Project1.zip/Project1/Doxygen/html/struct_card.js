var struct_card =
[
    [ "suit", "struct_card.html#a68d1b935f3e4830af01fb9dba6c8220a", null ],
    [ "type", "struct_card.html#ad7f5c3654b479f739fab1bcfed5e2765", null ],
    [ "value", "struct_card.html#a57c4269cef032dac1f282c9b2be3be4d", null ]
];