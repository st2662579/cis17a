var annotated_dup =
[
    [ "Card", "struct_card.html", "struct_card" ],
    [ "Deck", "struct_deck.html", "struct_deck" ]
];