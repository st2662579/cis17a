var struct_deck =
[
    [ "cards", "struct_deck.html#a3261f11ece5a7f756228634d79ed3649", null ],
    [ "size", "struct_deck.html#a8a6e5802d07c4e5181f624fbdd67f71f", null ]
];