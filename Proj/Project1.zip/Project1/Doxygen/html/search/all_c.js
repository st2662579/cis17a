var searchData=
[
  ['value',['value',['../struct_card.html#a57c4269cef032dac1f282c9b2be3be4d',1,'Card']]]
];
