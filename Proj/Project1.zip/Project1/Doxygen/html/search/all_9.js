var searchData=
[
  ['readable',['readable',['../main_8cpp.html#ae53a1efddfba94e6ef799cd2e3aee38f',1,'main.cpp']]],
  ['removefromdeck',['removeFromDeck',['../main_8cpp.html#a6c5cce92da3926454f88339594fa366f',1,'main.cpp']]],
  ['results',['results',['../main_8cpp.html#aa7f750eb7e3b8824185a76544bda8241',1,'main.cpp']]]
];
