var searchData=
[
  ['cards',['cards',['../struct_deck.html#a3261f11ece5a7f756228634d79ed3649',1,'Deck']]]
];
