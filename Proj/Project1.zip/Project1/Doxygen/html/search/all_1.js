var searchData=
[
  ['bestsum',['bestSum',['../main_8cpp.html#a1ea80b9302d5d1f8ed2face6fcbcb0b1',1,'main.cpp']]]
];
