var searchData=
[
  ['addcard',['addCard',['../main_8cpp.html#a48874f1b8651388316d09cc492f58825',1,'main.cpp']]]
];
