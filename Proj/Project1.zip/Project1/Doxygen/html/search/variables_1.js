var searchData=
[
  ['size',['size',['../struct_deck.html#a8a6e5802d07c4e5181f624fbdd67f71f',1,'Deck']]],
  ['suit',['suit',['../struct_card.html#a68d1b935f3e4830af01fb9dba6c8220a',1,'Card']]]
];
