var searchData=
[
  ['type',['type',['../struct_card.html#ad7f5c3654b479f739fab1bcfed5e2765',1,'Card']]]
];
